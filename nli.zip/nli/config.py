API = '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'

FINANCIAL_INSIGHTS_PROMPT = "Providing you with sales representative company inofrmation. Name of the company is {} and company work in industry of {} and company head Headquarters are located at {} with Specialties in {}. Sales representative company overview is as following {}. Now I am gonna provide you Prospect company information.Name of the prospect company is {} and company work in industry of {} and company head Headquarters are located at {} with Specialties in {} with company size of {} founded in {}. prospect company overview is as following {}. The Financial data of the prospect company is {}.Show how {} can offset their debt to liabilities of {}. showcase how {} can enhance {} customer experience, CSAT, ERG sustainability score, and show how {} can enhance the workforce of {} using {} Specialties. Also consider the following points {}"

FINANCIAL_INSIGHTS_MAX_TOKEN = 500
FINANCIAL_INSIGHTS_TEMPERATURE = 0.7
MODEL = "text-davinci-003"
